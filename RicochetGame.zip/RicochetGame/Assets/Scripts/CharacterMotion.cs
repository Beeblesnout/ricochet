﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterMotion : IDedSingletonBase
{
    public Transform head;
    public bool disableMovement;
    public float accel;
    public float deccel;
    public float maxSpeed;
    public float clampRate;
    public float lookSensitivity;
    public float jumpStrength;
    
    public GunController gun;
    public float gunRotateRate;
    Vector3 gunHeadPosOffset;
    public float gunPositionRate;

    [HideInInspector]
    public Rigidbody rb;
    [HideInInspector]
    public Vector2 moveInput;
    [HideInInspector]
    public Vector2 lookInput;
    [HideInInspector]
    public bool queueJump;
    [HideInInspector]
    public Vector3 headFlatForward;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        gunHeadPosOffset = gun.transform.position - head.position;
    }

    // temporary movement velocity
    Vector3 vel;
    private void FixedUpdate()
    {
        // Look Rotation
        head.Rotate(Vector3.up, lookInput.x * lookSensitivity, Space.World);
        head.Rotate(head.right, -lookInput.y * lookSensitivity, Space.World);

        if (!disableMovement)
        {
            // Movement
            headFlatForward = new Vector3(head.forward.x, 0, head.forward.z).normalized;
            vel += (head.right * moveInput.x + headFlatForward * moveInput.y) * accel;

            if (vel.magnitude > maxSpeed)
                vel = Vector3.Lerp(vel, vel.normalized * maxSpeed, clampRate);

            if (moveInput.magnitude == 0)
                vel -= vel.normalized * vel.magnitude * deccel;

            rb.velocity = new Vector3(vel.x, rb.velocity.y, vel.z);

            if (queueJump && Physics.Raycast(transform.position + Vector3.down * .9f, Vector3.down, .2f))
            {
                queueJump = false;
                rb.velocity = new Vector3(rb.velocity.x, 0, rb.velocity.z);
                rb.AddForce(Vector3.up * jumpStrength, ForceMode.Impulse);
            }
        }

        // Gun Rotation
        RaycastHit lookHit;
        bool hasLookHit = Physics.Raycast(head.position, head.forward, out lookHit, 100);
        if (hasLookHit)
            gun.transform.rotation = Quaternion.Lerp(gun.transform.rotation, Quaternion.LookRotation((lookHit.point - head.position).normalized, Vector3.up), gunRotateRate);
        else
            gun.transform.rotation = Quaternion.Lerp(gun.transform.rotation, Quaternion.LookRotation(head.forward, Vector3.up), gunRotateRate);

        if (transform.position.y < -10) 
            transform.position = Vector3.zero;

        // Gun Position
        // Vector3 newGunPos = Vector3.Lerp(gun.position, head.position + head.TransformPoint(gunHeadPosOffset), gunPositionRate);
        // gun.localPosition = gun.parent.InverseTransformPoint(newGunPos);
    }
}
