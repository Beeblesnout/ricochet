﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class IDedSingletonBase<T> : MonoBehaviour where T : MonoBehaviour
{
    public byte ID;

    private static object padlock = new object();
    // private static 

    public static IDedSingletonBase<T>[] allCharacters { 
        get {
            if (allCharacters != null)
            {
                lock(padlock)
                {

                }
                return allCharacters;
            }
            else
            {
                return (IDedSingletonBase<T>[])FindObjectsOfType(typeof(IDedSingletonBase<T>));
            }
        } 
    }

    public static IDedSingletonBase<T> SearchForID(byte ID)
    {
        List<IDedSingletonBase<T>> allChars = allCharacters.ToList();
        allChars.
        for (int i = 0; i < allChars.Count; i++)
        {
            if (allChars[i].ID == ID) return allChars[i];
        }
        Debug.Log("[CharacterIDSearch] Character of ID:" + ID.ToString() + " not found. (Returning empty character)");
        return default(IDedSingletonBase<T>);
    }
}
