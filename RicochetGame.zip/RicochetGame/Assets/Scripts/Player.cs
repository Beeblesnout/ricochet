﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : CharacterMotion
{
    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
    }

    void Update()
    {
        // Movement Input
        moveInput = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));

        // Mouse Input
        lookInput = new Vector2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y"));

        // Jump Input
        queueJump ^= Input.GetButtonDown("Jump");

        if (Input.mouseScrollDelta.y > 0)
            gun.ScrollGun(+1);
        else if (Input.mouseScrollDelta.y < 0)
            gun.ScrollGun(-1);
    }
}
